import BaseTextInput from './input';

export default BaseTextInput;