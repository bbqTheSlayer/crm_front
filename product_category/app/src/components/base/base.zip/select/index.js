import BaseSelect from './select';

export default BaseSelect;